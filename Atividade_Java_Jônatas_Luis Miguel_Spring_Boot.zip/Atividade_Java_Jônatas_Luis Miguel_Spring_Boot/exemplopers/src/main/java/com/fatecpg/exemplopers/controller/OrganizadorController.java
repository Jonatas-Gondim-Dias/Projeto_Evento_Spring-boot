package com.fatecpg.exemplopers.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fatecpg.exemplopers.model.Organizador;
import com.fatecpg.exemplopers.repository.OrganizadorRepository;

@RestController
@RequestMapping("/api/organizadores")
public class OrganizadorController {
    private final OrganizadorRepository repository;
    public OrganizadorController(OrganizadorRepository repository) { this.repository = repository; }

    @PostMapping public Organizador criar(@RequestBody Organizador obj) { return repository.save(obj); }
    @GetMapping public List<Organizador> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Organizador> buscar(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Organizador> atualizar(@PathVariable Long id, @RequestBody Organizador dados) {
        return repository.findById(id).map(obj -> {
            obj.setNome(dados.getNome()); obj.setEmail(dados.getEmail()); obj.setTelefone(dados.getTelefone());
            return ResponseEntity.ok(repository.save(obj));
        }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
