package com.fatecpg.exemplopers.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("PRESENCIAL")
@Getter @Setter @NoArgsConstructor
public class EventoPresencial extends Evento {
    private String endereco;
    private String cidade;
}
