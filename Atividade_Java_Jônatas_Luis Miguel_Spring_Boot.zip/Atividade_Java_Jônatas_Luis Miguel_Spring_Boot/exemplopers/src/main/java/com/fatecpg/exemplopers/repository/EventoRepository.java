package com.fatecpg.exemplopers.repository;
import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fatecpg.exemplopers.model.Evento;
public interface EventoRepository extends JpaRepository<Evento, Long> {
    List<Evento> findByOrganizadorId(Long organizadorId);
}
