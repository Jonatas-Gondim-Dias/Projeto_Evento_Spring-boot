package com.fatecpg.exemplopers.model;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import lombok.NoArgsConstructor;

@Entity
@DiscriminatorValue("ONLINE")
@Getter @Setter @NoArgsConstructor
public class EventoOnline extends Evento {
    private String plataforma;
    private String linkAcesso;
}
