package com.fatecpg.exemplopers.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fatecpg.exemplopers.model.Participante;
public interface ParticipanteRepository extends JpaRepository<Participante, Long> {}
