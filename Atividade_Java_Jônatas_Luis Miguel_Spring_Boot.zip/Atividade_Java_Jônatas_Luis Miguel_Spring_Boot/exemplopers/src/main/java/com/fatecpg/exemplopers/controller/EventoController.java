package com.fatecpg.exemplopers.controller;

import java.util.List;
import java.util.Set;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fatecpg.exemplopers.model.*;
import com.fatecpg.exemplopers.repository.*;

@RestController
@RequestMapping("/api/eventos")
public class EventoController {
    private final EventoRepository eventos;
    private final OrganizadorRepository organizadores;
    private final ParticipanteRepository participantes;

    public EventoController(EventoRepository eventos, OrganizadorRepository organizadores, ParticipanteRepository participantes) {
        this.eventos = eventos; this.organizadores = organizadores; this.participantes = participantes;
    }

    @GetMapping public List<Evento> listar() { return eventos.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Evento> buscar(@PathVariable Long id) {
        return eventos.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @GetMapping("/organizador/{id}") public List<Evento> porOrganizador(@PathVariable Long id) { return eventos.findByOrganizadorId(id); }

    @PostMapping("/presenciais") public ResponseEntity<?> criarPresencial(@RequestBody EventoPresencial dados, @RequestParam Long organizadorId) {
        var organizador = organizadores.findById(organizadorId);
        if (organizador.isEmpty()) return ResponseEntity.badRequest().body("Organizador não encontrado.");
        dados.setOrganizador(organizador.get());
        return ResponseEntity.ok(eventos.save(dados));
    }
    @PostMapping("/online") public ResponseEntity<?> criarOnline(@RequestBody EventoOnline dados, @RequestParam Long organizadorId) {
        var organizador = organizadores.findById(organizadorId);
        if (organizador.isEmpty()) return ResponseEntity.badRequest().body("Organizador não encontrado.");
        dados.setOrganizador(organizador.get());
        return ResponseEntity.ok(eventos.save(dados));
    }

    @PutMapping("/presenciais/{id}") public ResponseEntity<?> atualizarPresencial(@PathVariable Long id, @RequestBody EventoPresencial dados, @RequestParam Long organizadorId) {
        var encontrado = eventos.findById(id);
        if (encontrado.isEmpty()) return ResponseEntity.notFound().build();
        if (!(encontrado.get() instanceof EventoPresencial)) return ResponseEntity.badRequest().body("O evento informado não é presencial.");
        var organizador = organizadores.findById(organizadorId);
        if (organizador.isEmpty()) return ResponseEntity.badRequest().body("Organizador não encontrado.");
        EventoPresencial e = (EventoPresencial) encontrado.get();
        e.setTitulo(dados.getTitulo()); e.setDescricao(dados.getDescricao()); e.setData(dados.getData());
        e.setEndereco(dados.getEndereco()); e.setCidade(dados.getCidade()); e.setOrganizador(organizador.get());
        return ResponseEntity.ok(eventos.save(e));
    }
    @PutMapping("/online/{id}") public ResponseEntity<?> atualizarOnline(@PathVariable Long id, @RequestBody EventoOnline dados, @RequestParam Long organizadorId) {
        var encontrado = eventos.findById(id);
        if (encontrado.isEmpty()) return ResponseEntity.notFound().build();
        if (!(encontrado.get() instanceof EventoOnline)) return ResponseEntity.badRequest().body("O evento informado não é online.");
        var organizador = organizadores.findById(organizadorId);
        if (organizador.isEmpty()) return ResponseEntity.badRequest().body("Organizador não encontrado.");
        EventoOnline e = (EventoOnline) encontrado.get();
        e.setTitulo(dados.getTitulo()); e.setDescricao(dados.getDescricao()); e.setData(dados.getData());
        e.setPlataforma(dados.getPlataforma()); e.setLinkAcesso(dados.getLinkAcesso()); e.setOrganizador(organizador.get());
        return ResponseEntity.ok(eventos.save(e));
    }

    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!eventos.existsById(id)) return ResponseEntity.notFound().build();
        eventos.deleteById(id); return ResponseEntity.noContent().build();
    }

    @PostMapping("/{eventoId}/participantes/{participanteId}") public ResponseEntity<?> inscrever(@PathVariable Long eventoId, @PathVariable Long participanteId) {
        var evento = eventos.findById(eventoId);
        var participante = participantes.findById(participanteId);
        if (evento.isEmpty() || participante.isEmpty()) return ResponseEntity.notFound().build();
        evento.get().getParticipantes().add(participante.get());
        eventos.save(evento.get());
        return ResponseEntity.ok(evento.get());
    }
    @DeleteMapping("/{eventoId}/participantes/{participanteId}") public ResponseEntity<?> cancelarInscricao(@PathVariable Long eventoId, @PathVariable Long participanteId) {
        var evento = eventos.findById(eventoId);
        var participante = participantes.findById(participanteId);
        if (evento.isEmpty() || participante.isEmpty()) return ResponseEntity.notFound().build();
        evento.get().getParticipantes().remove(participante.get());
        eventos.save(evento.get());
        return ResponseEntity.noContent().build();
    }
}
