package com.fatecpg.exemplopers.controller;

import java.util.List;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.fatecpg.exemplopers.model.Participante;
import com.fatecpg.exemplopers.repository.ParticipanteRepository;
import com.fatecpg.exemplopers.repository.EventoRepository;

@RestController
@RequestMapping("/api/participantes")
public class ParticipanteController {
    private final ParticipanteRepository repository;
    private final EventoRepository eventos;
    public ParticipanteController(ParticipanteRepository repository, EventoRepository eventos) { this.repository = repository; this.eventos = eventos; }

    @PostMapping public Participante criar(@RequestBody Participante obj) { return repository.save(obj); }
    @GetMapping public List<Participante> listar() { return repository.findAll(); }
    @GetMapping("/{id}") public ResponseEntity<Participante> buscar(@PathVariable Long id) {
        return repository.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }
    @PutMapping("/{id}") public ResponseEntity<Participante> atualizar(@PathVariable Long id, @RequestBody Participante dados) {
        return repository.findById(id).map(obj -> {
            obj.setNome(dados.getNome()); obj.setEmail(dados.getEmail());
            return ResponseEntity.ok(repository.save(obj));
        }).orElse(ResponseEntity.notFound().build());
    }
    @DeleteMapping("/{id}") public ResponseEntity<Void> excluir(@PathVariable Long id) {
        if (!repository.existsById(id)) return ResponseEntity.notFound().build();
        var participante = repository.findById(id).get();
        eventos.findAll().forEach(evento -> evento.getParticipantes().remove(participante));
        eventos.flush();
        repository.deleteById(id); return ResponseEntity.noContent().build();
    }
}
