package com.fatecpg.exemplopers.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import com.fatecpg.exemplopers.model.Organizador;
public interface OrganizadorRepository extends JpaRepository<Organizador, Long> {}
